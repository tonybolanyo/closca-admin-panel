import * as i0 from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import * as i2 from '@angular/common/http';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i1 from '@angular/common';

/**
 * HTTP headers interface for better type safety.
 *
 * Defines the structure for HTTP headers that can be passed to service methods.
 * Headers can have string values or arrays of strings for multiple values.
 *
 * @interface HttpHeaderMap
 *
 * @example
 * ```typescript
 * const headers: HttpHeaderMap = {
 *   'Content-Type': 'application/json',
 *   'Authorization': 'Bearer token123',
 *   'Accept-Language': ['en-US', 'en', 'es']
 * };
 * ```
 */
interface HttpHeaderMap {
    [key: string]: string | string[];
}
/**
 * Generic storage value type for various storage handlers.
 *
 * Represents the types of values that can be stored in the various
 * storage mechanisms (localStorage, cookies, etc.).
 *
 * @type StorageValue
 *
 * @example
 * ```typescript
 * const stringValue: StorageValue = 'hello world';
 * const numberValue: StorageValue = 42;
 * const booleanValue: StorageValue = true;
 * const objectValue: StorageValue = { key: 'value' };
 * const nullValue: StorageValue = null;
 * ```
 */
type StorageValue = string | number | boolean | object | null;
/**
 * Authentication credentials interface for login operations.
 *
 * Defines the structure for user login credentials. Supports both
 * email and username-based authentication with flexible additional fields.
 *
 * @interface LoginCredentials
 *
 * @example
 * ```typescript
 * // Email-based login
 * const emailLogin: LoginCredentials = {
 *   email: 'user@example.com',
 *   password: 'password123'
 * };
 *
 * // Username-based login
 * const usernameLogin: LoginCredentials = {
 *   username: 'johndoe',
 *   password: 'password123'
 * };
 *
 * // With additional fields
 * const extendedLogin: LoginCredentials = {
 *   email: 'user@example.com',
 *   password: 'password123',
 *   rememberMe: true,
 *   captcha: 'abc123'
 * };
 * ```
 */
interface LoginCredentials {
    /**
     * User's email address (alternative to username).
     */
    email?: string;
    /**
     * User's username (alternative to email).
     */
    username?: string;
    /**
     * User's password (required for authentication).
     */
    password: string;
    /**
     * Additional fields for flexibility while maintaining type safety.
     * Allows extending credentials with custom fields like captcha, rememberMe, etc.
     */
    [key: string]: unknown;
}
/**
 * Password recovery request interface.
 *
 * Defines the structure for password recovery requests, typically
 * used to initiate the password reset process via email.
 *
 * @interface PasswordRecoveryRequest
 *
 * @example
 * ```typescript
 * const recoveryRequest: PasswordRecoveryRequest = {
 *   email: 'user@example.com'
 * };
 * ```
 */
interface PasswordRecoveryRequest {
    /**
     * The email address associated with the account to recover.
     */
    email: string;
}
/**
 * Password reset request interface.
 *
 * Defines the structure for password reset operations using a
 * recovery hash/token received via email.
 *
 * @interface PasswordResetRequest
 *
 * @example
 * ```typescript
 * const resetRequest: PasswordResetRequest = {
 *   newPassword: 'newSecurePassword123',
 *   hash: 'recovery-hash-from-email'
 * };
 * ```
 */
interface PasswordResetRequest {
    /**
     * The new password to set for the user account.
     */
    newPassword: string;
    /**
     * The recovery hash/token received from the password recovery email.
     */
    hash: string;
}
/**
 * Authentication response interface for login and authentication operations.
 *
 * Defines the expected structure of responses from authentication endpoints
 * such as login, registration, and password operations.
 *
 * @interface AuthenticationResponse
 *
 * @example
 * ```typescript
 * // Successful login response
 * const loginResponse: AuthenticationResponse = {
 *   token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
 *   user: { id: '123', name: 'John Doe', email: 'john@example.com' },
 *   message: 'Login successful',
 *   success: true
 * };
 *
 * // Error response
 * const errorResponse: AuthenticationResponse = {
 *   message: 'Invalid credentials',
 *   success: false,
 *   error: 'INVALID_CREDENTIALS'
 * };
 * ```
 */
interface AuthenticationResponse {
    /**
     * Authentication token (typically JWT) returned on successful authentication.
     */
    token?: string;
    /**
     * User object containing user information (can be overridden by generic T in services).
     */
    user?: Record<string, unknown>;
    /**
     * Human-readable message describing the result of the operation.
     */
    message?: string;
    /**
     * Boolean indicating whether the operation was successful.
     */
    success?: boolean;
    /**
     * Additional response fields while maintaining type safety.
     * Allows for custom fields like error codes, metadata, etc.
     */
    [key: string]: unknown;
}
/**
 * Generic API response interface for standardized API responses.
 *
 * Provides a consistent structure for API responses across the application.
 * Can be used with generic types to specify the expected data structure.
 *
 * @template T - The type of data expected in the response
 * @interface ApiResponse
 *
 * @example
 * ```typescript
 * // User data response
 * const userResponse: ApiResponse<User> = {
 *   data: { id: '123', name: 'John Doe', email: 'john@example.com' },
 *   message: 'User retrieved successfully',
 *   success: true
 * };
 *
 * // Error response
 * const errorResponse: ApiResponse = {
 *   message: 'Resource not found',
 *   success: false,
 *   error: 'NOT_FOUND'
 * };
 *
 * // List response
 * const usersResponse: ApiResponse<User[]> = {
 *   data: [{ id: '1', name: 'John' }, { id: '2', name: 'Jane' }],
 *   success: true
 * };
 * ```
 */
interface ApiResponse<T = Record<string, unknown>> {
    /**
     * The main data payload of the response.
     */
    data?: T;
    /**
     * Human-readable message describing the result.
     */
    message?: string;
    /**
     * Boolean indicating whether the operation was successful.
     */
    success?: boolean;
    /**
     * Error message or code when the operation fails.
     */
    error?: string;
    /**
     * Additional response fields while maintaining type safety.
     * Allows for pagination info, metadata, etc.
     */
    [key: string]: unknown;
}

/**
 * Abstract base class for all storage handlers.
 *
 * Provides a common interface for different storage mechanisms such as
 * localStorage, sessionStorage, cookies, etc. All storage implementations
 * should extend this class and implement the required methods.
 *
 * @abstract
 *
 * @example
 * ```typescript
 * class CustomStorage extends BaseStorage {
 *   get(key: string): StorageValue {
 *     // Custom implementation
 *     return customStorageApi.get(key);
 *   }
 *
 *   set(key: string, value: StorageValue, expires?: Date): void {
 *     // Custom implementation
 *     customStorageApi.set(key, value, expires);
 *   }
 *
 *   remove(key: string): void {
 *     // Custom implementation
 *     customStorageApi.remove(key);
 *   }
 * }
 * ```
 */
declare abstract class BaseStorage {
    /**
     * Retrieves a value from storage by key.
     *
     * @abstract
     * @param {string} key - The storage key to retrieve
     * @returns {StorageValue} The stored value or null if not found
     */
    abstract get(key: string): StorageValue;
    /**
     * Stores a value in storage with optional expiration.
     *
     * @abstract
     * @param {string} key - The storage key
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date
     */
    abstract set(key: string, value: StorageValue, expires?: Date): void;
    /**
     * Removes a value from storage by key.
     *
     * @abstract
     * @param {string} key - The storage key to remove
     */
    abstract remove(key: string): void;
}
/**
 * Abstract cookie storage handler.
 *
 * Specialized base class for cookie-based storage implementations.
 * Provides the same interface as BaseStorage but with cookie-specific semantics.
 *
 * @abstract
 * @extends BaseStorage
 *
 * @example
 * ```typescript
 * @Injectable()
 * class MyCookieStorage extends CookieStorage {
 *   // Implementation details...
 * }
 * ```
 */
declare abstract class CookieStorage extends BaseStorage {
    /**
     * Retrieves a value from cookie storage by key.
     *
     * @abstract
     * @override
     * @param {string} key - The cookie name to retrieve
     * @returns {StorageValue} The cookie value or null if not found
     */
    abstract get(key: string): StorageValue;
    /**
     * Stores a value in cookie storage with optional expiration.
     *
     * @abstract
     * @override
     * @param {string} key - The cookie name
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date
     */
    abstract set(key: string, value: StorageValue, expires?: Date): void;
    /**
     * Removes a cookie by name.
     *
     * @abstract
     * @override
     * @param {string} key - The cookie name to remove
     */
    abstract remove(key: string): void;
}
/**
 * Abstract web localStorage handler.
 *
 * Specialized base class for localStorage/sessionStorage-based implementations.
 * Provides the same interface as BaseStorage but with localStorage-specific semantics.
 *
 * @abstract
 * @extends BaseStorage
 *
 * @example
 * ```typescript
 * @Injectable()
 * class MyLocalStorage extends WebLocalStorage {
 *   // Implementation details...
 * }
 * ```
 */
declare abstract class WebLocalStorage extends BaseStorage {
    /**
     * Retrieves a value from web localStorage by key.
     *
     * @abstract
     * @override
     * @param {string} key - The localStorage key to retrieve
     * @returns {StorageValue} The stored value or null if not found
     */
    abstract get(key: string): StorageValue;
    /**
     * Stores a value in web localStorage with optional expiration.
     *
     * @abstract
     * @override
     * @param {string} key - The localStorage key
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date
     */
    abstract set(key: string, value: StorageValue, expires?: Date): void;
    /**
     * Removes a value from web localStorage by key.
     *
     * @abstract
     * @override
     * @param {string} key - The localStorage key to remove
     */
    abstract remove(key: string): void;
}

/**
 * CookieHandler provides browser cookie-based storage implementation.
 *
 * This service implements the BaseStorage interface using browser cookies.
 * It provides JSON serialization/deserialization and automatic expiration
 * handling. Cookies are accessible across different tabs and persist based
 * on their expiration settings.
 *
 * @implements {BaseStorage}
 *
 * @example
 * ```typescript
 * // Inject and use directly
 * constructor(private storage: CookieHandler) {}
 *
 * // Store simple data (session cookie)
 * this.storage.set('user_id', '12345');
 *
 * // Store with expiration
 * const expiresAt = new Date(Date.now() + 86400000); // 24 hours
 * this.storage.set('remember_token', 'abc123', expiresAt);
 *
 * // Store object (automatically JSON-serialized)
 * this.storage.set('user_prefs', { theme: 'dark' });
 *
 * // Retrieve data
 * const userId = this.storage.get('user_id');
 *
 * // Remove cookie
 * this.storage.remove('user_id');
 * ```
 */
declare class CookieHandler extends CookieStorage {
    /**
     * Retrieves a value from cookies by name.
     *
     * Parses the document.cookie string to find the specified cookie.
     * Attempts to parse values as JSON, falling back to string values
     * if parsing fails. Returns null if the cookie doesn't exist.
     *
     * @param {string} key - The cookie name to retrieve
     * @returns {StorageValue} The cookie value (parsed as JSON if possible) or null
     *
     * @example
     * ```typescript
     * // Get simple string cookie
     * const userId = this.storage.get('user_id'); // returns: "12345"
     *
     * // Get object cookie (automatically parsed from JSON)
     * const prefs = this.storage.get('user_prefs'); // returns: { theme: 'dark' }
     *
     * // Non-existent cookie
     * const missing = this.storage.get('nonexistent'); // returns: null
     * ```
     */
    get(key: string): StorageValue;
    /**
     * Sets a cookie with the specified name, value, and optional expiration.
     *
     * Objects are automatically JSON-serialized, while other values are converted
     * to strings. The cookie is set with path=/ to be accessible site-wide.
     *
     * @param {string} key - The cookie name
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date (creates session cookie if omitted)
     *
     * @example
     * ```typescript
     * // Set session cookie (expires when browser closes)
     * this.storage.set('session_id', 'abc123');
     *
     * // Set cookie with expiration
     * const oneWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
     * this.storage.set('remember_token', 'xyz789', oneWeek);
     *
     * // Set object cookie (automatically JSON-serialized)
     * this.storage.set('user_prefs', { theme: 'dark', lang: 'en' });
     * ```
     */
    set(key: string, value: StorageValue, expires?: Date): void;
    /**
     * Removes a cookie by setting its expiration to a past date.
     *
     * Uses the standard method of cookie deletion by setting the expiration
     * to January 1, 1970. The cookie is removed with path=/ to match the
     * path used when setting cookies.
     *
     * @param {string} key - The cookie name to remove
     *
     * @example
     * ```typescript
     * // Remove a cookie
     * this.storage.remove('user_session');
     *
     * // Cookie is immediately inaccessible after this call
     * const session = this.storage.get('user_session'); // returns: null
     * ```
     */
    remove(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CookieHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CookieHandler>;
}

/**
 * LocalStorageHandler provides browser localStorage-based storage implementation.
 *
 * This service implements the BaseStorage interface using the browser's localStorage API.
 * It provides JSON serialization/deserialization and handles expiration through
 * additional timestamp entries. The storage persists across browser sessions.
 *
 * @implements {BaseStorage}
 *
 * @example
 * ```typescript
 * // Inject and use directly
 * constructor(private storage: LocalStorageHandler) {}
 *
 * // Store data
 * this.storage.set('user_preferences', { theme: 'dark' });
 *
 * // Store with expiration
 * const expiresAt = new Date(Date.now() + 86400000); // 24 hours
 * this.storage.set('temp_data', 'some value', expiresAt);
 *
 * // Retrieve data
 * const preferences = this.storage.get('user_preferences');
 *
 * // Remove data
 * this.storage.remove('user_preferences');
 * ```
 */
declare class LocalStorageHandler extends WebLocalStorage {
    /**
     * Retrieves a value from localStorage by key.
     *
     * Attempts to parse stored values as JSON, falling back to string values
     * if parsing fails. Returns null if the key doesn't exist or if localStorage
     * is not available.
     *
     * @param {string} key - The localStorage key to retrieve
     * @returns {StorageValue} The stored value (parsed as JSON if possible) or null
     *
     * @example
     * ```typescript
     * // Get simple string
     * const name = this.storage.get('user_name'); // returns: "John Doe"
     *
     * // Get object (automatically parsed from JSON)
     * const settings = this.storage.get('user_settings'); // returns: { theme: 'dark' }
     *
     * // Non-existent key
     * const missing = this.storage.get('nonexistent'); // returns: null
     * ```
     */
    get(key: string): StorageValue;
    /**
     * Stores a value in localStorage with optional expiration.
     *
     * Objects are automatically JSON-serialized, while other values are converted
     * to strings. If an expiration date is provided, a separate timestamp entry
     * is stored to track expiration.
     *
     * @param {string} key - The localStorage key to store under
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date
     *
     * @example
     * ```typescript
     * // Store simple string
     * this.storage.set('user_name', 'John Doe');
     *
     * // Store object (automatically JSON-serialized)
     * this.storage.set('user_settings', { theme: 'dark', language: 'en' });
     *
     * // Store with expiration
     * const tomorrow = new Date(Date.now() + 86400000);
     * this.storage.set('temp_token', 'abc123', tomorrow);
     * ```
     */
    set(key: string, value: StorageValue, expires?: Date): void;
    /**
     * Gets the default expiration date (7 days from now).
     *
     * @private
     * @returns {Date} A date 7 days from the current time
     */
    private getDefaultExpiration;
    /**
     * Removes a value from localStorage by key.
     *
     * Removes both the main value and any associated expiration timestamp.
     * Does nothing if localStorage is not available.
     *
     * @param {string} key - The localStorage key to remove
     *
     * @example
     * ```typescript
     * // Remove stored data
     * this.storage.remove('user_settings');
     *
     * // Remove data with expiration (removes both main key and expiration key)
     * this.storage.remove('temp_token');
     * ```
     */
    remove(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalStorageHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalStorageHandler>;
}

/**
 * BaseModel provides a foundation class for all entity models in the application.
 *
 * This class defines the common structure that all entity models should extend.
 * It includes a unique identifier field and an instance field for additional data.
 *
 * @example
 * ```typescript
 * interface User extends BaseModel {
 *   name: string;
 *   email: string;
 *   createdAt: Date;
 * }
 *
 * class UserModel extends BaseModel implements User {
 *   name!: string;
 *   email!: string;
 *   createdAt!: Date;
 * }
 * ```
 */
declare class BaseModel {
    /**
     * Unique identifier for the entity.
     * Typically corresponds to the database primary key or MongoDB ObjectId.
     */
    _id?: string;
    /**
     * Additional instance data that can be attached to the model.
     * Useful for storing metadata or computed properties.
     */
    instance?: Record<string, unknown>;
}

/**
 * BaseService provides a generic foundation for HTTP-based CRUD operations.
 *
 * This abstract service class provides standard Create, Read, Update, Delete (CRUD)
 * operations for any entity that extends BaseModel. It includes methods for handling
 * HTTP headers, authentication, and common API patterns.
 *
 * @template T - The entity type that extends BaseModel
 *
 * @example
 * ```typescript
 * interface User extends BaseModel {
 *   name: string;
 *   email: string;
 * }
 *
 * @Injectable()
 * export class UserService extends BaseService<User> {
 *   constructor(http: HttpClient) {
 *     super(http);
 *     this.setApiConfig('https://api.example.com', 'users');
 *   }
 * }
 * ```
 */
declare abstract class BaseService<T extends BaseModel> {
    protected http: HttpClient;
    /**
     * Base URL for the API endpoint.
     * @protected
     */
    protected url: string;
    /**
     * Specific endpoint path for this service.
     * @protected
     */
    protected endpoint: string;
    /**
     * Default HTTP options with JSON content type.
     * @deprecated Use createHttpHeaders() method instead
     */
    httpOptions: {
        headers: HttpHeaders;
    };
    /**
     * Creates an instance of BaseService.
     *
     * @param {HttpClient} http - Angular HttpClient for making HTTP requests
     */
    constructor(http: HttpClient);
    /**
     * Configures the API base URL and endpoint for this service.
     *
     * @protected
     * @param {string} url - The base URL of the API
     * @param {string} endpoint - The specific endpoint path for this service
     *
     * @example
     * ```typescript
     * constructor(http: HttpClient) {
     *   super(http);
     *   this.setApiConfig('https://api.example.com', 'users');
     * }
     * ```
     */
    protected setApiConfig(url: string, endpoint: string): void;
    /**
     * Retrieves all entities from the API endpoint.
     *
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T[]>} Observable containing array of entities
     *
     * @example
     * ```typescript
     * this.userService.getAll().subscribe(users => {
     *   console.log('All users:', users);
     * });
     *
     * // With custom headers
     * this.userService.getAll({ 'Custom-Header': 'value' }).subscribe(users => {
     *   console.log('Users with custom header:', users);
     * });
     * ```
     */
    getAll(headers?: HttpHeaderMap): Observable<T[]>;
    /**
     * Retrieves a specific entity by its ID.
     *
     * @param {string} _id - The unique identifier of the entity
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the requested entity
     *
     * @example
     * ```typescript
     * this.userService.getById('123').subscribe(user => {
     *   console.log('User:', user);
     * });
     * ```
     */
    getById(_id: string, headers?: HttpHeaderMap): Observable<T>;
    /**
     * Creates a new entity via POST request.
     *
     * @param {T} item - The entity to create
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the created entity
     *
     * @example
     * ```typescript
     * const newUser = { name: 'John Doe', email: 'john@example.com' };
     * this.userService.create(newUser).subscribe(createdUser => {
     *   console.log('Created user:', createdUser);
     * });
     * ```
     */
    create(item: T, headers?: HttpHeaderMap): Observable<T>;
    /**
     * Partially updates an entity via PATCH request.
     *
     * Use this method when you want to update only specific fields of an entity.
     *
     * @param {string} _id - The unique identifier of the entity to update
     * @param {T} item - The partial entity data to update
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the updated entity
     *
     * @example
     * ```typescript
     * const updates = { name: 'Jane Doe' };
     * this.userService.update('123', updates).subscribe(updatedUser => {
     *   console.log('Updated user:', updatedUser);
     * });
     * ```
     */
    update(_id: string, item: T, headers?: HttpHeaderMap): Observable<T>;
    /**
     * Completely replaces an entity via PUT request.
     *
     * Use this method when you want to replace the entire entity with new data.
     *
     * @param {string} _id - The unique identifier of the entity to replace
     * @param {T} item - The complete entity data
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the updated entity
     *
     * @example
     * ```typescript
     * const completeUser = { name: 'Jane Smith', email: 'jane@example.com' };
     * this.userService.updateComplete('123', completeUser).subscribe(updatedUser => {
     *   console.log('Completely updated user:', updatedUser);
     * });
     * ```
     */
    updateComplete(_id: string, item: T, headers?: HttpHeaderMap): Observable<T>;
    /**
     * Deletes an entity via DELETE request.
     *
     * @param {string} _id - The unique identifier of the entity to delete
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<void>} Observable that completes when deletion is successful
     *
     * @example
     * ```typescript
     * this.userService.delete('123').subscribe(() => {
     *   console.log('User deleted successfully');
     * });
     * ```
     */
    delete(_id: string, headers?: HttpHeaderMap): Observable<void>;
    /**
     * Creates HttpHeaders with automatic authentication token injection.
     *
     * This method automatically includes the Authorization header with the current
     * authentication token (if available) and merges any additional headers provided.
     *
     * @param {HttpHeaderMap} [headers] - Optional additional headers to include
     * @returns {{ headers: HttpHeaders }} Object containing the configured HttpHeaders
     *
     * @example
     * ```typescript
     * const options = this.createHttpHeaders({ 'Custom-Header': 'value' });
     * return this.http.get('/api/data', options);
     * ```
     */
    createHttpHeaders(headers?: HttpHeaderMap): {
        headers: HttpHeaders;
    };
    /**
     * Creates HttpHeaders without authentication token injection.
     *
     * This method creates headers excluding the Authorization header, useful for
     * public endpoints or when manual authentication handling is required.
     *
     * @param {HttpHeaderMap} [headers] - Optional additional headers to include
     * @returns {{ headers: HttpHeaders }} Object containing the configured HttpHeaders (without auth)
     *
     * @example
     * ```typescript
     * const options = this.httpHeadersWithoutAuth({ 'Public-API-Key': 'key123' });
     * return this.http.get('/public/data', options);
     * ```
     */
    httpHeadersWithoutAuth(headers?: HttpHeaderMap): {
        headers: HttpHeaders;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseService<any>>;
}

/**
 * LoginBaseService extends BaseService with authentication-specific operations.
 *
 * This service provides methods for user authentication, registration, password
 * recovery, and user management. It builds upon the CRUD operations from BaseService
 * and adds authentication-specific endpoints.
 *
 * @template T - The user entity type that extends BaseModel
 *
 * @example
 * ```typescript
 * interface User extends BaseModel {
 *   username: string;
 *   email: string;
 *   role: string;
 * }
 *
 * @Injectable()
 * export class AuthService extends LoginBaseService<User> {
 *   constructor(http: HttpClient) {
 *     super(http);
 *     this.initializeConfig('https://api.example.com', 'auth');
 *   }
 * }
 * ```
 */
declare class LoginBaseService<T extends BaseModel> extends BaseService<T> {
    protected http: HttpClient;
    /**
     * Creates an instance of LoginBaseService.
     *
     * @param {HttpClient} http - Angular HttpClient for making HTTP requests
     */
    constructor(http: HttpClient);
    /**
     * Initializes the API configuration for authentication endpoints.
     *
     * This method should be called in the constructor of extending services
     * to set up the base URL and endpoint path.
     *
     * @param {string} url - The base URL of the API
     * @param {string} endpoint - The authentication endpoint path (e.g., 'auth', 'users')
     *
     * @example
     * ```typescript
     * constructor(http: HttpClient) {
     *   super(http);
     *   this.initializeConfig('https://api.example.com', 'auth');
     * }
     * ```
     */
    initializeConfig(url: string, endpoint: string): void;
    /**
     * Authenticates a user with the provided credentials.
     *
     * Sends a POST request to the /login endpoint with user credentials.
     *
     * @param {LoginCredentials} credentials - User login credentials (email/username and password)
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<AuthenticationResponse>} Observable containing authentication response with token
     *
     * @example
     * ```typescript
     * const credentials = { email: 'user@example.com', password: 'password123' };
     * this.authService.login(credentials).subscribe(response => {
     *   if (response.token) {
     *     // Store token and redirect user
     *     this.authService.setToken(response.token);
     *     this.router.navigate(['/dashboard']);
     *   }
     * });
     * ```
     */
    login(credentials: LoginCredentials, headers?: HttpHeaderMap): Observable<AuthenticationResponse>;
    /**
     * Initiates password recovery process for a user.
     *
     * Sends a POST request to the /reset endpoint with the user's email address.
     * The server typically sends a password reset link via email.
     *
     * @param {string} email - The email address of the user requesting password recovery
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<AuthenticationResponse>} Observable containing response with recovery status
     *
     * @example
     * ```typescript
     * this.authService.passwordRecovery('user@example.com').subscribe(response => {
     *   if (response.success) {
     *     console.log('Password recovery email sent');
     *   }
     * });
     * ```
     */
    passwordRecovery(email: string, headers?: HttpHeaderMap): Observable<AuthenticationResponse>;
    /**
     * Resets a user's password using a recovery hash.
     *
     * Sends a POST request to the /reset-password endpoint with the new password
     * and the hash token received from the password recovery email.
     *
     * @param {string} newPassword - The new password to set
     * @param {string} hash - The recovery hash/token from the password recovery email
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<AuthenticationResponse>} Observable containing reset confirmation
     *
     * @example
     * ```typescript
     * this.authService.resetPassword('newPassword123', 'recovery-hash-token').subscribe(response => {
     *   if (response.success) {
     *     console.log('Password reset successful');
     *     this.router.navigate(['/login']);
     *   }
     * });
     * ```
     */
    resetPassword(newPassword: string, hash: string, headers?: HttpHeaderMap): Observable<AuthenticationResponse>;
    /**
     * Retrieves the current authenticated user's information.
     *
     * Sends a GET request to the /me endpoint to fetch the current user's profile.
     * Requires a valid authentication token.
     *
     * @param {string} token - The authentication token (typically handled automatically by AuthInterceptor)
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the current user's information
     *
     * @example
     * ```typescript
     * this.authService.getCurrentUser('token').subscribe(user => {
     *   console.log('Current user:', user);
     *   this.currentUser = user;
     * });
     * ```
     */
    getCurrentUser(token: string, headers?: HttpHeaderMap): Observable<T>;
    /**
     * Registers a new user account.
     *
     * Sends a POST request to the /register endpoint with user registration data.
     *
     * @param {T} item - The user data for registration
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the created user data
     *
     * @example
     * ```typescript
     * const newUser = {
     *   username: 'johndoe',
     *   email: 'john@example.com',
     *   password: 'password123'
     * };
     *
     * this.authService.register(newUser).subscribe(user => {
     *   console.log('User registered:', user);
     *   // Optionally auto-login or redirect to login page
     * });
     * ```
     */
    register(item: T, headers?: HttpHeaderMap): Observable<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginBaseService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginBaseService<any>>;
}

/**
 * Interface defining the structure of an authentication token.
 *
 * This interface represents the data structure for authentication tokens
 * used throughout the application. It includes token identification,
 * expiration, creation time, and user association.
 *
 * @interface AuthTokenInterface
 *
 * @example
 * ```typescript
 * const tokenData: AuthTokenInterface = {
 *   id: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
 *   created: new Date(),
 *   ttl: Date.now() + (24 * 60 * 60 * 1000), // 24 hours
 *   userId: '12345'
 * };
 * ```
 */
interface AuthTokenInterface {
    /**
     * The token identifier or JWT string.
     * This is the actual token value used for authentication.
     */
    'id'?: string;
    /**
     * Time-to-live value indicating when the token expires.
     * Typically stored as milliseconds since epoch (timestamp).
     */
    'ttl'?: number;
    /**
     * The date and time when the token was created.
     * Used for token lifecycle management and logging.
     */
    'created'?: Date;
    /**
     * The unique identifier of the user associated with this token.
     * Links the token to a specific user account.
     */
    'userId'?: string;
}

/**
 * AuthToken model class that implements the AuthTokenInterface.
 *
 * This class represents an authentication token with its associated metadata
 * such as creation time, expiration, and user association. It provides
 * proper date handling and type safety for token operations.
 *
 * @implements {AuthTokenInterface}
 *
 * @example
 * ```typescript
 * // Create a new token
 * const tokenData = {
 *   id: 'jwt-token-string',
 *   created: new Date(),
 *   ttl: Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days from now
 *   userId: 'user123'
 * };
 * const token = new AuthToken(tokenData);
 *
 * // Create empty token
 * const emptyToken = new AuthToken();
 * ```
 */
declare class AuthToken implements AuthTokenInterface {
    /**
     * The token identifier/value (typically a JWT string).
     */
    id?: string;
    /**
     * Time-to-live timestamp indicating when the token expires.
     * Stored as milliseconds since epoch.
     */
    ttl?: number;
    /**
     * The date and time when the token was created.
     */
    created?: Date;
    /**
     * The unique identifier of the user associated with this token.
     */
    userId?: string;
    /**
     * Creates an instance of AuthToken.
     *
     * @param {AuthTokenInterface} [data] - Optional token data to initialize the instance
     *
     * @example
     * ```typescript
     * // With data
     * const token = new AuthToken({
     *   id: 'token123',
     *   created: new Date(),
     *   ttl: Date.now() + 86400000, // 24 hours
     *   userId: 'user456'
     * });
     *
     * // Empty token
     * const emptyToken = new AuthToken();
     * ```
     */
    constructor(data?: AuthTokenInterface);
}

/**
 * AuthService provides authentication token management functionality.
 *
 * This service handles the storage, retrieval, and management of authentication tokens
 * using LocalStorage as the default storage mechanism. It provides methods for setting,
 * getting, and removing authentication tokens, as well as persisting arbitrary data
 * with expiration dates.
 *
 * @example
 * ```typescript
 * // Inject the service
 * constructor(private authService: AuthService) {}
 *
 * // Set a token after login
 * this.authService.setToken('your-jwt-token');
 *
 * // Get the current token
 * const token = this.authService.getToken();
 *
 * // Remove token on logout
 * this.authService.removeToken();
 * ```
 */
declare class AuthService {
    private token;
    private storage;
    /**
     * Creates an instance of AuthService.
     * Initializes the LocalStorageHandler for token persistence.
     */
    constructor();
    /**
     * Retrieves the current authentication token.
     *
     * If no token is cached in memory, it attempts to load it from localStorage.
     * If no token exists in storage, returns an empty AuthToken instance.
     *
     * @returns {AuthToken} The current authentication token or an empty token if none exists
     *
     * @example
     * ```typescript
     * const token = this.authService.getToken();
     * if (token.id) {
     *   console.log('User is authenticated with token:', token.id);
     * } else {
     *   console.log('User is not authenticated');
     * }
     * ```
     */
    getToken(): AuthToken;
    /**
     * Sets a new authentication token and persists it to storage.
     *
     * Creates a new AuthToken with the provided token ID, current timestamp,
     * and default expiration time (7 days), then stores it in localStorage.
     *
     * @param {string} tokenId - The token identifier/value to store
     *
     * @example
     * ```typescript
     * // After successful login
     * this.authService.setToken(response.access_token);
     * ```
     */
    setToken(tokenId: string): void;
    /**
     * Removes the current authentication token from memory and storage.
     *
     * Clears both the in-memory token cache and removes the token from localStorage.
     * This method should be called when the user logs out.
     *
     * @example
     * ```typescript
     * // On logout
     * this.authService.removeToken();
     * this.router.navigate(['/login']);
     * ```
     */
    removeToken(): void;
    /**
     * Persists a value to storage with an optional expiration date.
     *
     * This method allows storing arbitrary key-value pairs with expiration.
     * If no expiration date is provided, defaults to 7 days from now.
     *
     * @param {string} token_property - The key under which to store the value
     * @param {StorageValue} value - The value to store (string, number, boolean, object, or null)
     * @param {Date} [expires] - Optional expiration date. Defaults to 7 days from now
     *
     * @example
     * ```typescript
     * // Store user preferences for 30 days
     * const thirtyDaysLater = new Date(Date.now() + (30 * 24 * 60 * 60 * 1000));
     * this.authService.persist('user_preferences', { theme: 'dark' }, thirtyDaysLater);
     *
     * // Store with default expiration (7 days)
     * this.authService.persist('temp_data', 'some value');
     * ```
     */
    persist(token_property: string, value: StorageValue, expires?: Date): void;
    /**
     * Calculates the default expiration time for tokens and stored data.
     *
     * @returns {Date} A date 7 days from the current time
     *
     * @example
     * ```typescript
     * const expiration = this.authService.expiresTime();
     * console.log('Token will expire on:', expiration);
     * ```
     */
    expiresTime(): Date;
    /**
     * Utility method to add days to a given date.
     *
     * @private
     * @param {Date} date - The base date
     * @param {number} days - The number of days to add
     * @returns {Date} A new date with the specified days added
     */
    private addDays;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthService>;
}

/**
 * Header key used to skip the authentication interceptor for specific requests.
 *
 * Add this header to HTTP requests that should not include authentication tokens.
 * Useful for public endpoints, login requests, or external API calls.
 *
 * @constant
 *
 * @example
 * ```typescript
 * import { HttpHeaders } from '@angular/common/http';
 * import { InterceptorSkipHeader } from '@gnommostudios/ng-gnommo-base';
 *
 * const headers = new HttpHeaders().set(InterceptorSkipHeader, 'true');
 * this.http.get('/public/endpoint', { headers });
 * ```
 */
declare const InterceptorSkipHeader = "X-Skip-Interceptor";
/**
 * AuthInterceptor automatically adds authentication tokens to HTTP requests.
 *
 * This interceptor automatically injects the Authorization header with the current
 * authentication token for all HTTP requests, except those marked with the skip header.
 * It retrieves the token from the AuthService and formats it as a Bearer token.
 *
 * The interceptor is automatically registered when importing NgGnommoBaseModule.forRoot().
 *
 * @implements {HttpInterceptor}
 *
 * @example
 * ```typescript
 * // The interceptor works automatically, but you can skip it for specific requests:
 *
 * // This request will include the auth token
 * this.http.get('/api/protected-data').subscribe(...);
 *
 * // This request will NOT include the auth token
 * const headers = new HttpHeaders().set(InterceptorSkipHeader, 'true');
 * this.http.get('/api/public-data', { headers }).subscribe(...);
 * ```
 */
declare class AuthInterceptor implements HttpInterceptor {
    private authService;
    /**
     * Creates an instance of AuthInterceptor.
     *
     * @param {AuthService} authService - The authentication service to retrieve tokens from
     */
    constructor(authService: AuthService);
    /**
     * Intercepts HTTP requests and adds authentication tokens automatically.
     *
     * This method is called for every HTTP request. It checks if the request
     * has the skip header, and if not, attempts to add the Authorization header
     * with the current authentication token from AuthService.
     *
     * @param {HttpRequest<any>} req - The outgoing HTTP request
     * @param {HttpHandler} next - The next handler in the interceptor chain
     * @returns {Observable<HttpEvent<any>>} Observable of the HTTP event
     *
     * @example
     * ```typescript
     * // This method is called automatically by Angular's HTTP client
     * // You don't need to call it directly, but here's what it does:
     *
     * // For requests without skip header:
     * // Original: GET /api/users
     * // Modified: GET /api/users with Authorization: Bearer <token>
     *
     * // For requests with skip header:
     * // Original: GET /api/public with X-Skip-Interceptor: true
     * // Modified: GET /api/public (skip header removed, no auth added)
     * ```
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthInterceptor>;
}

/**
 * ErrorInterceptor provides centralized HTTP error handling and logging.
 *
 * This interceptor catches HTTP errors from all requests and provides
 * consistent error logging and processing. It distinguishes between
 * client-side and server-side errors and logs them appropriately.
 *
 * The interceptor is automatically registered when importing NgGnommoBaseModule.forRoot().
 *
 * @implements {HttpInterceptor}
 *
 * @example
 * ```typescript
 * // The interceptor works automatically for all HTTP requests:
 *
 * this.http.get('/api/data').subscribe({
 *   next: (data) => console.log(data),
 *   error: (error) => {
 *     // Error has already been logged by the interceptor
 *     // Handle the error in your component
 *     console.log('Component handling error:', error);
 *   }
 * });
 * ```
 */
declare class ErrorInterceptor implements HttpInterceptor {
    /**
     * Creates an instance of ErrorInterceptor.
     */
    constructor();
    /**
     * Intercepts HTTP requests and handles any errors that occur.
     *
     * This method catches HTTP errors, logs them to the console with
     * appropriate formatting, and then re-throws the error for handling
     * by the calling component or service.
     *
     * @param {HttpRequest<any>} req - The outgoing HTTP request
     * @param {HttpHandler} next - The next handler in the interceptor chain
     * @returns {Observable<HttpEvent<any>>} Observable of the HTTP event
     *
     * @example
     * ```typescript
     * // This method is called automatically by Angular's HTTP client
     * // It will log errors like:
     *
     * // For client-side errors:
     * // "HTTP Error: Client Error: Network connection failed"
     *
     * // For server-side errors:
     * // "HTTP Error: Server Error Code: 404\nMessage: Not Found"
     * ```
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorInterceptor>;
}

/**
 * Console helper utilities for testing
 * Used to suppress expected warnings during test execution
 */
declare class ConsoleHelper {
    private static originalWarn;
    private static originalError;
    private static suppressedMessages;
    /**
     * Suppress console warnings for localStorage-related messages during tests
     */
    static suppressStorageWarnings(): void;
    /**
     * Restore original console methods
     */
    static restoreConsole(): void;
    /**
     * Execute a function with suppressed storage warnings
     * @param fn Function to execute with suppressed warnings
     */
    static withSuppressedStorageWarnings<T>(fn: () => T): T;
}

/**
 * AngularFoundationModule provides core functionality for Angular applications.
 *
 * This module includes authentication services, HTTP interceptors, storage handlers,
 * and base services for CRUD operations. It provides a complete foundation for
 * Angular applications that need authentication and API communication capabilities.
 *
 * ## Features Included:
 * - Authentication token management
 * - HTTP request/response interceptors
 * - Storage abstractions (localStorage, cookies)
 * - Base services for CRUD operations
 * - Type-safe interfaces and models
 *
 * @example
 * ```typescript
 * import { AngularFoundationModule } from '@tyris/angular-foundation';
 *
 * @NgModule({
 *   imports: [
 *     AngularFoundationModule.forRoot()
 *   ],
 *   // ...
 * })
 * export class AppModule { }
 * ```
 */
declare class AngularFoundationModule {
    /**
     * Configures the AngularFoundationModule with providers and interceptors.
     *
     * This static method should be called when importing the module in your
     * application's root module. It configures all the necessary providers,
     * HTTP interceptors, and storage handlers.
     *
     * ## Configured Providers:
     * - AuthService: Authentication token management
     * - LoginBaseService: Authentication operations (login, register, etc.)
     * - AuthInterceptor: Automatic token injection
     * - ErrorInterceptor: Centralized error handling
     * - LocalStorageHandler: Browser localStorage wrapper
     * - CookieHandler: Browser cookie wrapper
     *
     * @static
     * @returns {ModuleWithProviders<AngularFoundationModule>} Module with providers configuration
     *
     * @example
     * ```typescript
     * @NgModule({
     *   imports: [
     *     BrowserModule,
     *     AngularFoundationModule.forRoot()
     *   ],
     *   // ...
     * })
     * export class AppModule { }
     * ```
     */
    static forRoot(): ModuleWithProviders<AngularFoundationModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AngularFoundationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AngularFoundationModule, never, [typeof i1.CommonModule, typeof i2.HttpClientModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AngularFoundationModule>;
}

export { AngularFoundationModule, AuthInterceptor, AuthService, AuthToken, BaseModel, BaseService, BaseStorage, ConsoleHelper, CookieHandler, CookieStorage, ErrorInterceptor, InterceptorSkipHeader, LocalStorageHandler, LoginBaseService, WebLocalStorage };
export type { ApiResponse, AuthTokenInterface, AuthenticationResponse, HttpHeaderMap, LoginCredentials, PasswordRecoveryRequest, PasswordResetRequest, StorageValue };
