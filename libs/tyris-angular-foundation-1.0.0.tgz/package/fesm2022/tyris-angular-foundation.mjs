import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpHeaders, HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

/**
 * Abstract base class for all storage handlers.
 *
 * Provides a common interface for different storage mechanisms such as
 * localStorage, sessionStorage, cookies, etc. All storage implementations
 * should extend this class and implement the required methods.
 *
 * @abstract
 *
 * @example
 * ```typescript
 * class CustomStorage extends BaseStorage {
 *   get(key: string): StorageValue {
 *     // Custom implementation
 *     return customStorageApi.get(key);
 *   }
 *
 *   set(key: string, value: StorageValue, expires?: Date): void {
 *     // Custom implementation
 *     customStorageApi.set(key, value, expires);
 *   }
 *
 *   remove(key: string): void {
 *     // Custom implementation
 *     customStorageApi.remove(key);
 *   }
 * }
 * ```
 */
class BaseStorage {
}
/**
 * Abstract cookie storage handler.
 *
 * Specialized base class for cookie-based storage implementations.
 * Provides the same interface as BaseStorage but with cookie-specific semantics.
 *
 * @abstract
 * @extends BaseStorage
 *
 * @example
 * ```typescript
 * @Injectable()
 * class MyCookieStorage extends CookieStorage {
 *   // Implementation details...
 * }
 * ```
 */
class CookieStorage extends BaseStorage {
}
/**
 * Abstract web localStorage handler.
 *
 * Specialized base class for localStorage/sessionStorage-based implementations.
 * Provides the same interface as BaseStorage but with localStorage-specific semantics.
 *
 * @abstract
 * @extends BaseStorage
 *
 * @example
 * ```typescript
 * @Injectable()
 * class MyLocalStorage extends WebLocalStorage {
 *   // Implementation details...
 * }
 * ```
 */
class WebLocalStorage extends BaseStorage {
}

/**
 * CookieHandler provides browser cookie-based storage implementation.
 *
 * This service implements the BaseStorage interface using browser cookies.
 * It provides JSON serialization/deserialization and automatic expiration
 * handling. Cookies are accessible across different tabs and persist based
 * on their expiration settings.
 *
 * @implements {BaseStorage}
 *
 * @example
 * ```typescript
 * // Inject and use directly
 * constructor(private storage: CookieHandler) {}
 *
 * // Store simple data (session cookie)
 * this.storage.set('user_id', '12345');
 *
 * // Store with expiration
 * const expiresAt = new Date(Date.now() + 86400000); // 24 hours
 * this.storage.set('remember_token', 'abc123', expiresAt);
 *
 * // Store object (automatically JSON-serialized)
 * this.storage.set('user_prefs', { theme: 'dark' });
 *
 * // Retrieve data
 * const userId = this.storage.get('user_id');
 *
 * // Remove cookie
 * this.storage.remove('user_id');
 * ```
 */
class CookieHandler extends CookieStorage {
    /**
     * Retrieves a value from cookies by name.
     *
     * Parses the document.cookie string to find the specified cookie.
     * Attempts to parse values as JSON, falling back to string values
     * if parsing fails. Returns null if the cookie doesn't exist.
     *
     * @param {string} key - The cookie name to retrieve
     * @returns {StorageValue} The cookie value (parsed as JSON if possible) or null
     *
     * @example
     * ```typescript
     * // Get simple string cookie
     * const userId = this.storage.get('user_id'); // returns: "12345"
     *
     * // Get object cookie (automatically parsed from JSON)
     * const prefs = this.storage.get('user_prefs'); // returns: { theme: 'dark' }
     *
     * // Non-existent cookie
     * const missing = this.storage.get('nonexistent'); // returns: null
     * ```
     */
    get(key) {
        try {
            if (typeof document === 'undefined' || !document) {
                return null;
            }
            const nameEQ = key + '=';
            const ca = document.cookie.split(';');
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) === ' ') {
                    c = c.substring(1, c.length);
                }
                if (c.indexOf(nameEQ) === 0) {
                    const encodedValue = c.substring(nameEQ.length, c.length);
                    const value = decodeURIComponent(encodedValue);
                    try {
                        return JSON.parse(value);
                    }
                    catch (e) {
                        return value;
                    }
                }
            }
            return null;
        }
        catch (error) {
            // Handle cookie access errors gracefully
            return null;
        }
    }
    /**
     * Sets a cookie with the specified name, value, and optional expiration.
     *
     * Objects are automatically JSON-serialized, while other values are converted
     * to strings. The cookie is set with path=/ to be accessible site-wide.
     *
     * @param {string} key - The cookie name
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date (creates session cookie if omitted)
     *
     * @example
     * ```typescript
     * // Set session cookie (expires when browser closes)
     * this.storage.set('session_id', 'abc123');
     *
     * // Set cookie with expiration
     * const oneWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
     * this.storage.set('remember_token', 'xyz789', oneWeek);
     *
     * // Set object cookie (automatically JSON-serialized)
     * this.storage.set('user_prefs', { theme: 'dark', lang: 'en' });
     * ```
     */
    set(key, value, expires) {
        try {
            if (typeof document === 'undefined' || !document) {
                return; // Silently fail when document is unavailable
            }
            const encodedValue = encodeURIComponent(typeof value === 'object' ? JSON.stringify(value) : String(value));
            let cookie = key + '=' + encodedValue;
            if (expires) {
                cookie += '; expires=' + expires.toUTCString();
            }
            cookie += '; path=/';
            document.cookie = cookie;
        }
        catch (error) {
            // Handle cookie setting errors gracefully (e.g., when cookies are disabled)
            // Silently fail to maintain compatibility
        }
    }
    /**
     * Removes a cookie by setting its expiration to a past date.
     *
     * Uses the standard method of cookie deletion by setting the expiration
     * to January 1, 1970. The cookie is removed with path=/ to match the
     * path used when setting cookies.
     *
     * @param {string} key - The cookie name to remove
     *
     * @example
     * ```typescript
     * // Remove a cookie
     * this.storage.remove('user_session');
     *
     * // Cookie is immediately inaccessible after this call
     * const session = this.storage.get('user_session'); // returns: null
     * ```
     */
    remove(key) {
        try {
            if (typeof document === 'undefined' || !document) {
                return; // Silently fail when document is unavailable
            }
            document.cookie = key + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
        }
        catch (error) {
            // Handle cookie removal errors gracefully (e.g., when cookies are disabled)
            // Silently fail to maintain compatibility
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: CookieHandler, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: CookieHandler });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: CookieHandler, decorators: [{
            type: Injectable
        }] });

/**
 * LocalStorageHandler provides browser localStorage-based storage implementation.
 *
 * This service implements the BaseStorage interface using the browser's localStorage API.
 * It provides JSON serialization/deserialization and handles expiration through
 * additional timestamp entries. The storage persists across browser sessions.
 *
 * @implements {BaseStorage}
 *
 * @example
 * ```typescript
 * // Inject and use directly
 * constructor(private storage: LocalStorageHandler) {}
 *
 * // Store data
 * this.storage.set('user_preferences', { theme: 'dark' });
 *
 * // Store with expiration
 * const expiresAt = new Date(Date.now() + 86400000); // 24 hours
 * this.storage.set('temp_data', 'some value', expiresAt);
 *
 * // Retrieve data
 * const preferences = this.storage.get('user_preferences');
 *
 * // Remove data
 * this.storage.remove('user_preferences');
 * ```
 */
class LocalStorageHandler extends WebLocalStorage {
    /**
     * Retrieves a value from localStorage by key.
     *
     * Attempts to parse stored values as JSON, falling back to string values
     * if parsing fails. Returns null if the key doesn't exist or if localStorage
     * is not available.
     *
     * @param {string} key - The localStorage key to retrieve
     * @returns {StorageValue} The stored value (parsed as JSON if possible) or null
     *
     * @example
     * ```typescript
     * // Get simple string
     * const name = this.storage.get('user_name'); // returns: "John Doe"
     *
     * // Get object (automatically parsed from JSON)
     * const settings = this.storage.get('user_settings'); // returns: { theme: 'dark' }
     *
     * // Non-existent key
     * const missing = this.storage.get('nonexistent'); // returns: null
     * ```
     */
    get(key) {
        if (typeof Storage !== 'undefined' && localStorage) {
            try {
                const storedData = localStorage.getItem(key);
                if (storedData) {
                    try {
                        const parsedData = JSON.parse(storedData);
                        // Check if this is the new format with expiration
                        if (parsedData && typeof parsedData === 'object' && parsedData.hasOwnProperty('value')) {
                            // Check expiration if present
                            if (parsedData.expires) {
                                const expirationDate = new Date(parsedData.expires);
                                if (expirationDate.getTime() < Date.now()) {
                                    // Item has expired, remove it and return null
                                    this.remove(key);
                                    return null;
                                }
                            }
                            return parsedData.value;
                        }
                        else {
                            // Fallback for old format or direct values
                            return parsedData;
                        }
                    }
                    catch (e) {
                        // If JSON parsing fails, return null for corrupted data
                        return null;
                    }
                }
            }
            catch (error) {
                console.warn('LocalStorage unavailable:', error);
            }
        }
        return null;
    }
    /**
     * Stores a value in localStorage with optional expiration.
     *
     * Objects are automatically JSON-serialized, while other values are converted
     * to strings. If an expiration date is provided, a separate timestamp entry
     * is stored to track expiration.
     *
     * @param {string} key - The localStorage key to store under
     * @param {StorageValue} value - The value to store
     * @param {Date} [expires] - Optional expiration date
     *
     * @example
     * ```typescript
     * // Store simple string
     * this.storage.set('user_name', 'John Doe');
     *
     * // Store object (automatically JSON-serialized)
     * this.storage.set('user_settings', { theme: 'dark', language: 'en' });
     *
     * // Store with expiration
     * const tomorrow = new Date(Date.now() + 86400000);
     * this.storage.set('temp_token', 'abc123', tomorrow);
     * ```
     */
    set(key, value, expires) {
        if (typeof Storage !== 'undefined' && localStorage) {
            try {
                const storageData = { value };
                // Always add expiration - use provided date or default to 7 days from now
                const expirationDate = expires || this.getDefaultExpiration();
                storageData.expires = expirationDate.toISOString();
                localStorage.setItem(key, JSON.stringify(storageData));
            }
            catch (error) {
                // Handle storage quota exceeded or other storage errors silently
                console.warn('LocalStorage unavailable:', error);
            }
        }
    }
    /**
     * Gets the default expiration date (7 days from now).
     *
     * @private
     * @returns {Date} A date 7 days from the current time
     */
    getDefaultExpiration() {
        const date = new Date();
        date.setDate(date.getDate() + 7);
        return date;
    }
    /**
     * Removes a value from localStorage by key.
     *
     * Removes both the main value and any associated expiration timestamp.
     * Does nothing if localStorage is not available.
     *
     * @param {string} key - The localStorage key to remove
     *
     * @example
     * ```typescript
     * // Remove stored data
     * this.storage.remove('user_settings');
     *
     * // Remove data with expiration (removes both main key and expiration key)
     * this.storage.remove('temp_token');
     * ```
     */
    remove(key) {
        if (typeof Storage !== 'undefined' && localStorage) {
            try {
                localStorage.removeItem(key);
                // Note: No longer removing separate _expires key since we use integrated format
            }
            catch (error) {
                console.warn('LocalStorage unavailable:', error);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: LocalStorageHandler, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: LocalStorageHandler });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: LocalStorageHandler, decorators: [{
            type: Injectable
        }] });

/**
 * BaseService provides a generic foundation for HTTP-based CRUD operations.
 *
 * This abstract service class provides standard Create, Read, Update, Delete (CRUD)
 * operations for any entity that extends BaseModel. It includes methods for handling
 * HTTP headers, authentication, and common API patterns.
 *
 * @template T - The entity type that extends BaseModel
 *
 * @example
 * ```typescript
 * interface User extends BaseModel {
 *   name: string;
 *   email: string;
 * }
 *
 * @Injectable()
 * export class UserService extends BaseService<User> {
 *   constructor(http: HttpClient) {
 *     super(http);
 *     this.setApiConfig('https://api.example.com', 'users');
 *   }
 * }
 * ```
 */
class BaseService {
    http;
    /**
     * Base URL for the API endpoint.
     * @protected
     */
    url = '';
    /**
     * Specific endpoint path for this service.
     * @protected
     */
    endpoint = '';
    /**
     * Default HTTP options with JSON content type.
     * @deprecated Use createHttpHeaders() method instead
     */
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    };
    /**
     * Creates an instance of BaseService.
     *
     * @param {HttpClient} http - Angular HttpClient for making HTTP requests
     */
    constructor(http) {
        this.http = http;
    }
    /**
     * Configures the API base URL and endpoint for this service.
     *
     * @protected
     * @param {string} url - The base URL of the API
     * @param {string} endpoint - The specific endpoint path for this service
     *
     * @example
     * ```typescript
     * constructor(http: HttpClient) {
     *   super(http);
     *   this.setApiConfig('https://api.example.com', 'users');
     * }
     * ```
     */
    setApiConfig(url, endpoint) {
        this.url = url;
        this.endpoint = endpoint;
    }
    /**
     * Retrieves all entities from the API endpoint.
     *
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T[]>} Observable containing array of entities
     *
     * @example
     * ```typescript
     * this.userService.getAll().subscribe(users => {
     *   console.log('All users:', users);
     * });
     *
     * // With custom headers
     * this.userService.getAll({ 'Custom-Header': 'value' }).subscribe(users => {
     *   console.log('Users with custom header:', users);
     * });
     * ```
     */
    getAll(headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.get(`${this.url}/${this.endpoint}`, options);
    }
    /**
     * Retrieves a specific entity by its ID.
     *
     * @param {string} _id - The unique identifier of the entity
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the requested entity
     *
     * @example
     * ```typescript
     * this.userService.getById('123').subscribe(user => {
     *   console.log('User:', user);
     * });
     * ```
     */
    getById(_id, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.get(`${this.url}/${this.endpoint}/${_id}`, options);
    }
    /**
     * Creates a new entity via POST request.
     *
     * @param {T} item - The entity to create
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the created entity
     *
     * @example
     * ```typescript
     * const newUser = { name: 'John Doe', email: 'john@example.com' };
     * this.userService.create(newUser).subscribe(createdUser => {
     *   console.log('Created user:', createdUser);
     * });
     * ```
     */
    create(item, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.post(`${this.url}/${this.endpoint}`, item, options);
    }
    /**
     * Partially updates an entity via PATCH request.
     *
     * Use this method when you want to update only specific fields of an entity.
     *
     * @param {string} _id - The unique identifier of the entity to update
     * @param {T} item - The partial entity data to update
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the updated entity
     *
     * @example
     * ```typescript
     * const updates = { name: 'Jane Doe' };
     * this.userService.update('123', updates).subscribe(updatedUser => {
     *   console.log('Updated user:', updatedUser);
     * });
     * ```
     */
    update(_id, item, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.patch(`${this.url}/${this.endpoint}/${_id}`, item, options);
    }
    /**
     * Completely replaces an entity via PUT request.
     *
     * Use this method when you want to replace the entire entity with new data.
     *
     * @param {string} _id - The unique identifier of the entity to replace
     * @param {T} item - The complete entity data
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the updated entity
     *
     * @example
     * ```typescript
     * const completeUser = { name: 'Jane Smith', email: 'jane@example.com' };
     * this.userService.updateComplete('123', completeUser).subscribe(updatedUser => {
     *   console.log('Completely updated user:', updatedUser);
     * });
     * ```
     */
    updateComplete(_id, item, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.put(`${this.url}/${this.endpoint}/${_id}`, item, options);
    }
    /**
     * Deletes an entity via DELETE request.
     *
     * @param {string} _id - The unique identifier of the entity to delete
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<void>} Observable that completes when deletion is successful
     *
     * @example
     * ```typescript
     * this.userService.delete('123').subscribe(() => {
     *   console.log('User deleted successfully');
     * });
     * ```
     */
    delete(_id, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.delete(`${this.url}/${this.endpoint}/${_id}`, options);
    }
    /**
     * Creates HttpHeaders with automatic authentication token injection.
     *
     * This method automatically includes the Authorization header with the current
     * authentication token (if available) and merges any additional headers provided.
     *
     * @param {HttpHeaderMap} [headers] - Optional additional headers to include
     * @returns {{ headers: HttpHeaders }} Object containing the configured HttpHeaders
     *
     * @example
     * ```typescript
     * const options = this.createHttpHeaders({ 'Custom-Header': 'value' });
     * return this.http.get('/api/data', options);
     * ```
     */
    createHttpHeaders(headers) {
        let httpHeaders = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        if (headers) {
            Object.keys(headers).forEach(key => {
                const value = headers[key];
                if (typeof value === 'string') {
                    httpHeaders = httpHeaders.set(key, value);
                }
                else if (Array.isArray(value)) {
                    httpHeaders = httpHeaders.set(key, value.join(', '));
                }
            });
        }
        return { headers: httpHeaders };
    }
    /**
     * Creates HttpHeaders without authentication token injection.
     *
     * This method creates headers excluding the Authorization header, useful for
     * public endpoints or when manual authentication handling is required.
     *
     * @param {HttpHeaderMap} [headers] - Optional additional headers to include
     * @returns {{ headers: HttpHeaders }} Object containing the configured HttpHeaders (without auth)
     *
     * @example
     * ```typescript
     * const options = this.httpHeadersWithoutAuth({ 'Public-API-Key': 'key123' });
     * return this.http.get('/public/data', options);
     * ```
     */
    httpHeadersWithoutAuth(headers) {
        let httpHeaders = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        if (headers) {
            Object.keys(headers).forEach(key => {
                if (key.toLowerCase() !== 'authorization') {
                    const value = headers[key];
                    if (typeof value === 'string') {
                        httpHeaders = httpHeaders.set(key, value);
                    }
                    else if (Array.isArray(value)) {
                        httpHeaders = httpHeaders.set(key, value.join(', '));
                    }
                }
            });
        }
        return { headers: httpHeaders };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: BaseService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: BaseService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: BaseService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

/**
 * LoginBaseService extends BaseService with authentication-specific operations.
 *
 * This service provides methods for user authentication, registration, password
 * recovery, and user management. It builds upon the CRUD operations from BaseService
 * and adds authentication-specific endpoints.
 *
 * @template T - The user entity type that extends BaseModel
 *
 * @example
 * ```typescript
 * interface User extends BaseModel {
 *   username: string;
 *   email: string;
 *   role: string;
 * }
 *
 * @Injectable()
 * export class AuthService extends LoginBaseService<User> {
 *   constructor(http: HttpClient) {
 *     super(http);
 *     this.initializeConfig('https://api.example.com', 'auth');
 *   }
 * }
 * ```
 */
class LoginBaseService extends BaseService {
    http;
    /**
     * Creates an instance of LoginBaseService.
     *
     * @param {HttpClient} http - Angular HttpClient for making HTTP requests
     */
    constructor(http) {
        super(http);
        this.http = http;
    }
    /**
     * Initializes the API configuration for authentication endpoints.
     *
     * This method should be called in the constructor of extending services
     * to set up the base URL and endpoint path.
     *
     * @param {string} url - The base URL of the API
     * @param {string} endpoint - The authentication endpoint path (e.g., 'auth', 'users')
     *
     * @example
     * ```typescript
     * constructor(http: HttpClient) {
     *   super(http);
     *   this.initializeConfig('https://api.example.com', 'auth');
     * }
     * ```
     */
    initializeConfig(url, endpoint) {
        this.setApiConfig(url, endpoint);
    }
    /**
     * Authenticates a user with the provided credentials.
     *
     * Sends a POST request to the /login endpoint with user credentials.
     *
     * @param {LoginCredentials} credentials - User login credentials (email/username and password)
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<AuthenticationResponse>} Observable containing authentication response with token
     *
     * @example
     * ```typescript
     * const credentials = { email: 'user@example.com', password: 'password123' };
     * this.authService.login(credentials).subscribe(response => {
     *   if (response.token) {
     *     // Store token and redirect user
     *     this.authService.setToken(response.token);
     *     this.router.navigate(['/dashboard']);
     *   }
     * });
     * ```
     */
    login(credentials, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.post(`${this.url}/${this.endpoint}/login`, credentials, options);
    }
    /**
     * Initiates password recovery process for a user.
     *
     * Sends a POST request to the /reset endpoint with the user's email address.
     * The server typically sends a password reset link via email.
     *
     * @param {string} email - The email address of the user requesting password recovery
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<AuthenticationResponse>} Observable containing response with recovery status
     *
     * @example
     * ```typescript
     * this.authService.passwordRecovery('user@example.com').subscribe(response => {
     *   if (response.success) {
     *     console.log('Password recovery email sent');
     *   }
     * });
     * ```
     */
    passwordRecovery(email, headers) {
        const options = this.createHttpHeaders(headers);
        const request = { email };
        return this.http.post(`${this.url}/${this.endpoint}/reset`, request, options);
    }
    /**
     * Resets a user's password using a recovery hash.
     *
     * Sends a POST request to the /reset-password endpoint with the new password
     * and the hash token received from the password recovery email.
     *
     * @param {string} newPassword - The new password to set
     * @param {string} hash - The recovery hash/token from the password recovery email
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<AuthenticationResponse>} Observable containing reset confirmation
     *
     * @example
     * ```typescript
     * this.authService.resetPassword('newPassword123', 'recovery-hash-token').subscribe(response => {
     *   if (response.success) {
     *     console.log('Password reset successful');
     *     this.router.navigate(['/login']);
     *   }
     * });
     * ```
     */
    resetPassword(newPassword, hash, headers) {
        const options = this.createHttpHeaders(headers);
        const request = { newPassword, hash };
        return this.http.post(`${this.url}/${this.endpoint}/reset-password`, request, options);
    }
    /**
     * Retrieves the current authenticated user's information.
     *
     * Sends a GET request to the /me endpoint to fetch the current user's profile.
     * Requires a valid authentication token.
     *
     * @param {string} token - The authentication token (typically handled automatically by AuthInterceptor)
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the current user's information
     *
     * @example
     * ```typescript
     * this.authService.getCurrentUser('token').subscribe(user => {
     *   console.log('Current user:', user);
     *   this.currentUser = user;
     * });
     * ```
     */
    getCurrentUser(token, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.get(`${this.url}/${this.endpoint}/me`, options);
    }
    /**
     * Registers a new user account.
     *
     * Sends a POST request to the /register endpoint with user registration data.
     *
     * @param {T} item - The user data for registration
     * @param {HttpHeaderMap} [headers] - Optional additional HTTP headers
     * @returns {Observable<T>} Observable containing the created user data
     *
     * @example
     * ```typescript
     * const newUser = {
     *   username: 'johndoe',
     *   email: 'john@example.com',
     *   password: 'password123'
     * };
     *
     * this.authService.register(newUser).subscribe(user => {
     *   console.log('User registered:', user);
     *   // Optionally auto-login or redirect to login page
     * });
     * ```
     */
    register(item, headers) {
        const options = this.createHttpHeaders(headers);
        return this.http.post(`${this.url}/${this.endpoint}/register`, item, options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: LoginBaseService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: LoginBaseService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: LoginBaseService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

/**
 * AuthToken model class that implements the AuthTokenInterface.
 *
 * This class represents an authentication token with its associated metadata
 * such as creation time, expiration, and user association. It provides
 * proper date handling and type safety for token operations.
 *
 * @implements {AuthTokenInterface}
 *
 * @example
 * ```typescript
 * // Create a new token
 * const tokenData = {
 *   id: 'jwt-token-string',
 *   created: new Date(),
 *   ttl: Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days from now
 *   userId: 'user123'
 * };
 * const token = new AuthToken(tokenData);
 *
 * // Create empty token
 * const emptyToken = new AuthToken();
 * ```
 */
class AuthToken {
    /**
     * The token identifier/value (typically a JWT string).
     */
    id;
    /**
     * Time-to-live timestamp indicating when the token expires.
     * Stored as milliseconds since epoch.
     */
    ttl;
    /**
     * The date and time when the token was created.
     */
    created;
    /**
     * The unique identifier of the user associated with this token.
     */
    userId;
    /**
     * Creates an instance of AuthToken.
     *
     * @param {AuthTokenInterface} [data] - Optional token data to initialize the instance
     *
     * @example
     * ```typescript
     * // With data
     * const token = new AuthToken({
     *   id: 'token123',
     *   created: new Date(),
     *   ttl: Date.now() + 86400000, // 24 hours
     *   userId: 'user456'
     * });
     *
     * // Empty token
     * const emptyToken = new AuthToken();
     * ```
     */
    constructor(data) {
        if (data) {
            this.id = data.id;
            this.ttl = data.ttl;
            // Handle created property with null preservation and backward compatibility
            if (data.created === null) {
                this.created = null;
            }
            else if (data.created instanceof Date) {
                this.created = data.created;
            }
            else if (data.created) {
                // For string dates, try to parse as Date first
                if (typeof data.created === 'string') {
                    // Check if it's an ISO date string (which should be converted to Date)
                    const isoDateRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z?$/;
                    if (isoDateRegex.test(data.created)) {
                        this.created = new Date(data.created);
                    }
                    else {
                        // For non-ISO strings, preserve as-is for backward compatibility
                        this.created = data.created;
                    }
                }
                else {
                    this.created = new Date(data.created);
                }
            }
            else {
                this.created = undefined;
            }
            this.userId = data.userId;
        }
    }
}

/**
 * AuthService provides authentication token management functionality.
 *
 * This service handles the storage, retrieval, and management of authentication tokens
 * using LocalStorage as the default storage mechanism. It provides methods for setting,
 * getting, and removing authentication tokens, as well as persisting arbitrary data
 * with expiration dates.
 *
 * @example
 * ```typescript
 * // Inject the service
 * constructor(private authService: AuthService) {}
 *
 * // Set a token after login
 * this.authService.setToken('your-jwt-token');
 *
 * // Get the current token
 * const token = this.authService.getToken();
 *
 * // Remove token on logout
 * this.authService.removeToken();
 * ```
 */
class AuthService {
    token = null;
    storage;
    /**
     * Creates an instance of AuthService.
     * Initializes the LocalStorageHandler for token persistence.
     */
    constructor() {
        this.storage = new LocalStorageHandler();
    }
    /**
     * Retrieves the current authentication token.
     *
     * If no token is cached in memory, it attempts to load it from localStorage.
     * If no token exists in storage, returns an empty AuthToken instance.
     *
     * @returns {AuthToken} The current authentication token or an empty token if none exists
     *
     * @example
     * ```typescript
     * const token = this.authService.getToken();
     * if (token.id) {
     *   console.log('User is authenticated with token:', token.id);
     * } else {
     *   console.log('User is not authenticated');
     * }
     * ```
     */
    getToken() {
        if (!this.token) {
            const tokenData = this.storage.get('access_token');
            if (tokenData && typeof tokenData === 'object') {
                this.token = new AuthToken(tokenData);
            }
            else {
                this.token = new AuthToken();
            }
        }
        return this.token;
    }
    /**
     * Sets a new authentication token and persists it to storage.
     *
     * Creates a new AuthToken with the provided token ID, current timestamp,
     * and default expiration time (7 days), then stores it in localStorage.
     *
     * @param {string} tokenId - The token identifier/value to store
     *
     * @example
     * ```typescript
     * // After successful login
     * this.authService.setToken(response.access_token);
     * ```
     */
    setToken(tokenId) {
        const tokenData = {
            id: tokenId,
            created: new Date(),
            ttl: this.expiresTime().getTime()
        };
        this.token = new AuthToken(tokenData);
        this.storage.set('access_token', tokenData, this.expiresTime());
    }
    /**
     * Removes the current authentication token from memory and storage.
     *
     * Clears both the in-memory token cache and removes the token from localStorage.
     * This method should be called when the user logs out.
     *
     * @example
     * ```typescript
     * // On logout
     * this.authService.removeToken();
     * this.router.navigate(['/login']);
     * ```
     */
    removeToken() {
        this.token = null;
        this.storage.remove('access_token');
    }
    /**
     * Persists a value to storage with an optional expiration date.
     *
     * This method allows storing arbitrary key-value pairs with expiration.
     * If no expiration date is provided, defaults to 7 days from now.
     *
     * @param {string} token_property - The key under which to store the value
     * @param {StorageValue} value - The value to store (string, number, boolean, object, or null)
     * @param {Date} [expires] - Optional expiration date. Defaults to 7 days from now
     *
     * @example
     * ```typescript
     * // Store user preferences for 30 days
     * const thirtyDaysLater = new Date(Date.now() + (30 * 24 * 60 * 60 * 1000));
     * this.authService.persist('user_preferences', { theme: 'dark' }, thirtyDaysLater);
     *
     * // Store with default expiration (7 days)
     * this.authService.persist('temp_data', 'some value');
     * ```
     */
    persist(token_property, value, expires) {
        const expirationDate = expires || this.expiresTime();
        this.storage.set(token_property, value, expirationDate);
    }
    /**
     * Calculates the default expiration time for tokens and stored data.
     *
     * @returns {Date} A date 7 days from the current time
     *
     * @example
     * ```typescript
     * const expiration = this.authService.expiresTime();
     * console.log('Token will expire on:', expiration);
     * ```
     */
    expiresTime() {
        return this.addDays(new Date(), 7); // Default 7 days expiration
    }
    /**
     * Utility method to add days to a given date.
     *
     * @private
     * @param {Date} date - The base date
     * @param {number} days - The number of days to add
     * @returns {Date} A new date with the specified days added
     */
    addDays(date, days) {
        const result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

/**
 * Header key used to skip the authentication interceptor for specific requests.
 *
 * Add this header to HTTP requests that should not include authentication tokens.
 * Useful for public endpoints, login requests, or external API calls.
 *
 * @constant
 *
 * @example
 * ```typescript
 * import { HttpHeaders } from '@angular/common/http';
 * import { InterceptorSkipHeader } from '@gnommostudios/ng-gnommo-base';
 *
 * const headers = new HttpHeaders().set(InterceptorSkipHeader, 'true');
 * this.http.get('/public/endpoint', { headers });
 * ```
 */
const InterceptorSkipHeader = 'X-Skip-Interceptor';
/**
 * AuthInterceptor automatically adds authentication tokens to HTTP requests.
 *
 * This interceptor automatically injects the Authorization header with the current
 * authentication token for all HTTP requests, except those marked with the skip header.
 * It retrieves the token from the AuthService and formats it as a Bearer token.
 *
 * The interceptor is automatically registered when importing NgGnommoBaseModule.forRoot().
 *
 * @implements {HttpInterceptor}
 *
 * @example
 * ```typescript
 * // The interceptor works automatically, but you can skip it for specific requests:
 *
 * // This request will include the auth token
 * this.http.get('/api/protected-data').subscribe(...);
 *
 * // This request will NOT include the auth token
 * const headers = new HttpHeaders().set(InterceptorSkipHeader, 'true');
 * this.http.get('/api/public-data', { headers }).subscribe(...);
 * ```
 */
class AuthInterceptor {
    authService;
    /**
     * Creates an instance of AuthInterceptor.
     *
     * @param {AuthService} authService - The authentication service to retrieve tokens from
     */
    constructor(authService) {
        this.authService = authService;
    }
    /**
     * Intercepts HTTP requests and adds authentication tokens automatically.
     *
     * This method is called for every HTTP request. It checks if the request
     * has the skip header, and if not, attempts to add the Authorization header
     * with the current authentication token from AuthService.
     *
     * @param {HttpRequest<any>} req - The outgoing HTTP request
     * @param {HttpHandler} next - The next handler in the interceptor chain
     * @returns {Observable<HttpEvent<any>>} Observable of the HTTP event
     *
     * @example
     * ```typescript
     * // This method is called automatically by Angular's HTTP client
     * // You don't need to call it directly, but here's what it does:
     *
     * // For requests without skip header:
     * // Original: GET /api/users
     * // Modified: GET /api/users with Authorization: Bearer <token>
     *
     * // For requests with skip header:
     * // Original: GET /api/public with X-Skip-Interceptor: true
     * // Modified: GET /api/public (skip header removed, no auth added)
     * ```
     */
    intercept(req, next) {
        // Check if the request has the skip header
        if (req.headers.has(InterceptorSkipHeader)) {
            const newReq = req.clone({
                headers: req.headers.delete(InterceptorSkipHeader)
            });
            return next.handle(newReq);
        }
        // Get the auth token with error handling
        let authToken;
        try {
            authToken = this.authService.getToken();
        }
        catch (error) {
            // If getting token fails, continue without authentication header
            return next.handle(req);
        }
        // Clone the request and add the authorization header if token exists
        if (authToken && authToken.id) {
            const authReq = req.clone({
                headers: req.headers.set('Authorization', `Bearer ${authToken.id}`)
            });
            return next.handle(authReq);
        }
        return next.handle(req);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthInterceptor, deps: [{ token: AuthService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthInterceptor });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: AuthService }] });

/**
 * ErrorInterceptor provides centralized HTTP error handling and logging.
 *
 * This interceptor catches HTTP errors from all requests and provides
 * consistent error logging and processing. It distinguishes between
 * client-side and server-side errors and logs them appropriately.
 *
 * The interceptor is automatically registered when importing NgGnommoBaseModule.forRoot().
 *
 * @implements {HttpInterceptor}
 *
 * @example
 * ```typescript
 * // The interceptor works automatically for all HTTP requests:
 *
 * this.http.get('/api/data').subscribe({
 *   next: (data) => console.log(data),
 *   error: (error) => {
 *     // Error has already been logged by the interceptor
 *     // Handle the error in your component
 *     console.log('Component handling error:', error);
 *   }
 * });
 * ```
 */
class ErrorInterceptor {
    /**
     * Creates an instance of ErrorInterceptor.
     */
    constructor() { }
    /**
     * Intercepts HTTP requests and handles any errors that occur.
     *
     * This method catches HTTP errors, logs them to the console with
     * appropriate formatting, and then re-throws the error for handling
     * by the calling component or service.
     *
     * @param {HttpRequest<any>} req - The outgoing HTTP request
     * @param {HttpHandler} next - The next handler in the interceptor chain
     * @returns {Observable<HttpEvent<any>>} Observable of the HTTP event
     *
     * @example
     * ```typescript
     * // This method is called automatically by Angular's HTTP client
     * // It will log errors like:
     *
     * // For client-side errors:
     * // "HTTP Error: Client Error: Network connection failed"
     *
     * // For server-side errors:
     * // "HTTP Error: Server Error Code: 404\nMessage: Not Found"
     * ```
     */
    intercept(req, next) {
        return next.handle(req).pipe(catchError((error) => {
            // Log the error to console (in production, you might want to send this to a logging service)
            console.error('HTTP Error occurred:', error);
            return throwError(error);
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: ErrorInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: ErrorInterceptor });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: ErrorInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

/**
 * BaseModel provides a foundation class for all entity models in the application.
 *
 * This class defines the common structure that all entity models should extend.
 * It includes a unique identifier field and an instance field for additional data.
 *
 * @example
 * ```typescript
 * interface User extends BaseModel {
 *   name: string;
 *   email: string;
 *   createdAt: Date;
 * }
 *
 * class UserModel extends BaseModel implements User {
 *   name!: string;
 *   email!: string;
 *   createdAt!: Date;
 * }
 * ```
 */
class BaseModel {
    /**
     * Unique identifier for the entity.
     * Typically corresponds to the database primary key or MongoDB ObjectId.
     */
    _id;
    /**
     * Additional instance data that can be attached to the model.
     * Useful for storing metadata or computed properties.
     */
    instance;
}

/**
 * Console helper utilities for testing
 * Used to suppress expected warnings during test execution
 */
class ConsoleHelper {
    static originalWarn = console.warn;
    static originalError = console.error;
    static suppressedMessages = [
        'LocalStorage unavailable:',
        'localStorage quota exceeded',
        'localStorage not available'
    ];
    /**
     * Suppress console warnings for localStorage-related messages during tests
     */
    static suppressStorageWarnings() {
        console.warn = (...args) => {
            const message = args.join(' ');
            const shouldSuppress = this.suppressedMessages.some(suppressed => message.includes(suppressed));
            if (!shouldSuppress) {
                this.originalWarn.apply(console, args);
            }
        };
        console.error = (...args) => {
            const message = args.join(' ');
            const shouldSuppress = this.suppressedMessages.some(suppressed => message.includes(suppressed));
            if (!shouldSuppress) {
                this.originalError.apply(console, args);
            }
        };
    }
    /**
     * Restore original console methods
     */
    static restoreConsole() {
        console.warn = this.originalWarn;
        console.error = this.originalError;
    }
    /**
     * Execute a function with suppressed storage warnings
     * @param fn Function to execute with suppressed warnings
     */
    static withSuppressedStorageWarnings(fn) {
        this.suppressStorageWarnings();
        try {
            return fn();
        }
        finally {
            this.restoreConsole();
        }
    }
}

/**
 * AngularFoundationModule provides core functionality for Angular applications.
 *
 * This module includes authentication services, HTTP interceptors, storage handlers,
 * and base services for CRUD operations. It provides a complete foundation for
 * Angular applications that need authentication and API communication capabilities.
 *
 * ## Features Included:
 * - Authentication token management
 * - HTTP request/response interceptors
 * - Storage abstractions (localStorage, cookies)
 * - Base services for CRUD operations
 * - Type-safe interfaces and models
 *
 * @example
 * ```typescript
 * import { AngularFoundationModule } from '@tyris/angular-foundation';
 *
 * @NgModule({
 *   imports: [
 *     AngularFoundationModule.forRoot()
 *   ],
 *   // ...
 * })
 * export class AppModule { }
 * ```
 */
class AngularFoundationModule {
    /**
     * Configures the AngularFoundationModule with providers and interceptors.
     *
     * This static method should be called when importing the module in your
     * application's root module. It configures all the necessary providers,
     * HTTP interceptors, and storage handlers.
     *
     * ## Configured Providers:
     * - AuthService: Authentication token management
     * - LoginBaseService: Authentication operations (login, register, etc.)
     * - AuthInterceptor: Automatic token injection
     * - ErrorInterceptor: Centralized error handling
     * - LocalStorageHandler: Browser localStorage wrapper
     * - CookieHandler: Browser cookie wrapper
     *
     * @static
     * @returns {ModuleWithProviders<AngularFoundationModule>} Module with providers configuration
     *
     * @example
     * ```typescript
     * @NgModule({
     *   imports: [
     *     BrowserModule,
     *     AngularFoundationModule.forRoot()
     *   ],
     *   // ...
     * })
     * export class AppModule { }
     * ```
     */
    static forRoot() {
        return {
            ngModule: AngularFoundationModule,
            providers: [
                // Services
                AuthService,
                LoginBaseService,
                // Interceptors
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: AuthInterceptor,
                    multi: true
                },
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: ErrorInterceptor,
                    multi: true
                },
                // Storage
                {
                    provide: WebLocalStorage,
                    useClass: LocalStorageHandler
                },
                {
                    provide: CookieStorage,
                    useClass: CookieHandler
                }
            ]
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AngularFoundationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.4", ngImport: i0, type: AngularFoundationModule, imports: [CommonModule,
            HttpClientModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AngularFoundationModule, imports: [CommonModule,
            HttpClientModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AngularFoundationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        HttpClientModule
                    ]
                }]
        }] });

// Storage

/*
 * Public API Surface of angular-foundation
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AngularFoundationModule, AuthInterceptor, AuthService, AuthToken, BaseModel, BaseService, BaseStorage, ConsoleHelper, CookieHandler, CookieStorage, ErrorInterceptor, InterceptorSkipHeader, LocalStorageHandler, LoginBaseService, WebLocalStorage };
//# sourceMappingURL=tyris-angular-foundation.mjs.map
